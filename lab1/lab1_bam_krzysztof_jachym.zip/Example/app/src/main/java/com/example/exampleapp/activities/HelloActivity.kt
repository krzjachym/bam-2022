package com.example.exampleapp.activities

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.exampleapp.ExampleApplication
import com.example.exampleapp.R
import com.example.exampleapp.receiver.NumberReceiver
import com.example.exampleapp.receiver.NumberReceiver.Companion.NUMBER_RECEIVER_ACTION
import com.example.exampleapp.room.User
import com.example.exampleapp.services.SimpleService
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class HelloActivity : AppCompatActivity() {

    companion object {
        const val USER_NAME_EXTRA = "USER_NAME"
        val TAG = HelloActivity::class.java.canonicalName
    }



    private val startServiceButton by lazy {findViewById<Button>(R.id.startServiceBtn)}
    private val stopServiceButton by lazy {findViewById<Button>(R.id.stopServiceBtn)}
    private val readUsersButton by lazy {findViewById<Button>(R.id.readUsersBtn)}
    private val userTextView by lazy {findViewById<TextView>(R.id.myUserName)}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hello)

        val userName = intent.getStringExtra(USER_NAME_EXTRA)
        userTextView.text= getString(R.string.hello_user_text, userName)

        startServiceButton.setOnClickListener { onStartServiceBtnClick() }
        stopServiceButton.setOnClickListener{ onStopServiceBtnClick() }
        readUsersButton.setOnClickListener { onReadUsersBtnClick() }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun onStartServiceBtnClick() {
        val serviceIntent = Intent(this, SimpleService::class.java)
        val userName = intent.getStringExtra(USER_NAME_EXTRA)
        serviceIntent.putExtra(SimpleService.SERVICE_USER_NAME,userName)
        startService(serviceIntent)
    }

    private fun onStopServiceBtnClick() {
        val intent = Intent(this, SimpleService::class.java)
        stopService(intent)
    }

    private fun onReadUsersBtnClick(){
        GlobalScope.launch {
            val users: List<User> =
                (applicationContext as ExampleApplication).database.userDao().getAll()
            for(user in users)
            {
                Log.d(TAG, "onReadUsersBtnClick: username: ${user.userName}, number: ${user.number}")
            }

        }
    }
}