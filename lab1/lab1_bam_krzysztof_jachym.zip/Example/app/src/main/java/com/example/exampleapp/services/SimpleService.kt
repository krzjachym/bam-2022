package com.example.exampleapp.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import com.example.exampleapp.activities.HelloActivity
import com.example.exampleapp.receiver.NumberReceiver
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.lang.Thread.sleep

class SimpleService : Service() {

    var isDestroyed = false;

    var serviceNum = 0
    companion object {
        val TAG = SimpleService.javaClass.canonicalName
        const val SERVICE_USER_NAME = "serviceUserName"
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        serviceNum += 1
        Log.d(TAG,"Starting service number $serviceNum")
        val userName = intent?.getStringExtra(SERVICE_USER_NAME)
        GlobalScope.launch {
            var number = 0;
            while (!isDestroyed) {
                number++;
                Log.d(TAG, "New number $number");
                delay(1000);
            }

            val broadcastIntent = Intent(NumberReceiver.NUMBER_RECEIVER_ACTION)
            broadcastIntent.putExtra(NumberReceiver.USER_NAME_EXTRA,userName)
            broadcastIntent.putExtra(NumberReceiver.NUMBER_EXTRA,number)
            sendBroadcast(broadcastIntent)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        isDestroyed = true;
        super.onDestroy()
    }

}