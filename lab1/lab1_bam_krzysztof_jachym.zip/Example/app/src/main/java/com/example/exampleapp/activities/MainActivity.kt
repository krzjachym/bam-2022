package com.example.exampleapp.activities

import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.room.Database
import androidx.room.Room
import com.example.exampleapp.ExampleApplication
import com.example.exampleapp.R
import com.example.exampleapp.receiver.NumberReceiver
import com.example.exampleapp.room.AppDatabase
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private val userNameInput by lazy { findViewById<TextInputEditText>(R.id.userName) }

    private val button by lazy{findViewById<Button?>(R.id.button)}
    private val receiver: BroadcastReceiver = NumberReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button?.setOnClickListener { startHelloActivity() }

//        button?.setOnClickListener(object: View.OnClickListener{
//            override fun onClick(p0: View?) {
//                startHelloActivity()
//            }
//        })

        val filter = IntentFilter(NumberReceiver.NUMBER_RECEIVER_ACTION)

        registerReceiver(receiver,filter)


    }

    override fun onDestroy() {
        (applicationContext as ExampleApplication).database.close()

        super.onDestroy()
        unregisterReceiver(receiver)
    }

    private fun startHelloActivity(){
        val intent = Intent(this,HelloActivity::class.java)
        val userName = userNameInput.text.toString()
        intent.putExtra(HelloActivity.USER_NAME_EXTRA, userName)
        startActivity(intent)
    }
}